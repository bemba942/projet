/******************************************************************************/
/* general tags */
html {
    font-size: 82%;
}

input, select, textarea {
    font-size: 1em;
}

body {
    font-family:        sans-serif;
    background:         #D0DCE0;
    color:              #000000;
    margin:             0;
    padding:            0.2em 0.2em 0.2em 0.2em;
}

a img {
    border: 0;
}

a:link,
a:visited,
a:active {
    text-decoration:    none;
    color:              #0000FF;
}

ul {
    margin:0;
}

form {
    margin:             0;
    padding:            0;
    display:            inline;
}

select#select_server,
select#lightm_db {
    width:              100%;
}

/* buttons in some browsers (eg. Konqueror) are block elements,
   this breaks design */
button {
    display:            inline;
}


/******************************************************************************/
/* classes */

/* leave some space between icons and text */
.icon {
    vertical-align:     middle;
    margin-right:       0.3em;
    margin-left:        0.3em;
}

.navi_dbName {
    font-weight:    bold;
    color:          #0000FF;
}

/******************************************************************************/
/* specific elements */

div#pmalogo {
        background-color: #D0DCE0;
    padding:.3em;
}
div#pmalogo,
div#leftframelinks,
div#databaseList {
    text-align:         center;
    margin-bottom:      0.5em;
    padding-bottom:     0.5em;
}

ul#databaseList {
    margin-bottom:      0.5em;
    padding-bottom:     0.5em;
    padding-left:     1.5em;
}

ul#databaseList a {
    display: block;
}

div#navidbpageselector a,
ul#databaseList a {
    background:         #D0DCE0;
    color:              #000000;
}

ul#databaseList a:hover {
    background:         #9999CC;
    color:              #000000;
}

ul#databaseList li.selected a {
    background: #FFCC99;
    color: #000000;
}

div#leftframelinks .icon {
    padding:            0;
    margin:             0;
}

div#leftframelinks a img.icon {
    margin:             0;
    padding:            0.2em;
    border:             0.05em solid #000000;
}

div#leftframelinks a:hover {
    background:         #9999CC;
    color:              #000000;
}

/* serverlist */
#body_leftFrame #list_server {
    list-style-image: url(./themes/original/img/s_host.png);
    list-style-position: inside;
    list-style-type: none;
    margin: 0;
    padding: 0;
}

#body_leftFrame #list_server li {
    margin: 0;
    padding: 0;
    font-size:          80%;
}

div#left_tableList ul {
    list-style-type:    none;
    list-style-position: outside;
    margin:             0;
    padding:            0;
    font-size:          80%;
    background:         #D0DCE0;
}

div#left_tableList ul ul {
    font-size:          100%;
}

div#left_tableList a {
    background:         #D0DCE0;
    color:              #000000;
    text-decoration:    none;
}

div#left_tableList a:hover {
    background:         #D0DCE0;
    color:              #000000;
    text-decoration:    underline;
}

div#left_tableList li {
    margin:             0;
    padding:            0;
    white-space:        nowrap;
}

/* marked items */
div#left_tableList > ul li.marked > a,
div#left_tableList > ul li.marked {
    background: #FFCC99;
    color: #000000;
}

div#left_tableList > ul li:hover > a,
div#left_tableList > ul li:hover {
    background:         #9999CC;
    color:              #000000;
}

div#left_tableList img {
    padding:            0;
    vertical-align:     middle;
}

div#left_tableList ul ul {
    margin-left:        0;
    padding-left:       0.1em;
    border-left:        0.1em solid #000000;
    padding-bottom:     0.1em;
    border-bottom:      0.1em solid #000000;
}

/* for the servers list in navi panel */
#serverinfo .item {
    white-space:        nowrap;
    color:              #000000;
}
#serverinfo a:hover {
    background:         #9999CC;
    color:              #000000;
}
